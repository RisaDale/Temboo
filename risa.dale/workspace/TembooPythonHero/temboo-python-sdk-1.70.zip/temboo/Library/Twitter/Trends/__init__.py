from Weekly import *
from Daily import *
from Available import *
