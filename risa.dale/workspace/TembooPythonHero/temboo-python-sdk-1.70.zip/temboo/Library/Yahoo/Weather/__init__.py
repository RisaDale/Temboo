from GetWeatherByAddress import *
from GetWeather import *
from GetWeatherByCoordinates import *
