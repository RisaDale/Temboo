from CreatePeople import *
from ShowPeople import *
from DeletePeople import *
from SearchPeople import *
from ListAllPeople import *
